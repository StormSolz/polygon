#include "Update.h"
#include "Variables.h"

#include "../UnrealEngine/GameplayStatics.h"
#include "../UnrealEngine/KismetSystemLibrary.h"
#include "../UnrealEngine/GameClasses.h"

#include "Features/Visuals.h"
#include "Features/Aimbot.h"

cUpdate update;

void cUpdate::GameThread(UGameViewportClient* viewport, UCanvas* canvas)
{
    do
    {
        memset(&Info, NULL, sizeof(Info));

       auto const world = *SDK->GWorld;
       if (!world) break;

       auto const gameState = world->GameState();
       if (!gameState) break;

       auto const gameInstance = viewport->GameInstance();
       if (!gameInstance) break;

       auto const localPlayer = gameInstance->LocalPlayers()[0];
       if (!localPlayer) break;

       auto const localController = localPlayer->PlayerController();
       if (!localController) break;

       Info.PlayerController = localController;

       auto const localCharacter = localController->K2_GetPawn();
       if (!localCharacter) break;

       Info.localCharacter = localCharacter;

       Info.good = true;

       auto const localPlayerState = localController->PlayerState();
       if (!localPlayerState) break;

       auto const playerArray = gameState->PlayerArray();
       if (!playerArray[0]) break;

       Info.playerArray = playerArray;

       for (int i = 0; i < playerArray.Count; i++)
       {
            if (!playerArray.IsValidIndex(i)) continue;

            auto const playerState = playerArray[i];
            if (!playerState) continue;

            auto const playerPawn = playerState->PawnPrivate();
            if (!playerPawn) continue;

            if (playerPawn == localCharacter) continue;

            auto const actorComponent = ((APG_Character*)playerPawn)->HealthStatsComponent();
            if (!actorComponent) continue;

            auto const playerHealth = actorComponent->GetHealth();
            if (playerHealth == 0) continue;

            if (((APG_PlayerState_Game*)localPlayerState)->Team() == ((APG_PlayerState_Game*)playerState)->Team()) continue;

            bool playerVisible = localController->LineOfSightTo(playerPawn, FVector(), false);

            Aimbot->Run(localController, (APG_Character*)playerPawn, playerVisible);

            FVector Origin, Extend;
            playerPawn->GetActorBounds(true, &Origin, &Extend, false);

            const FVector location = playerPawn->K2_GetActorLocation(); 

            FVector2D footPos;
            if (!localController->ProjectWorldLocationToScreen({ location.X, location.Y, location.Z + Extend.Z }, &footPos, false)) continue;

            FVector2D headPos;
            if (!localController->ProjectWorldLocationToScreen({ location.X, location.Y, location.Z - Extend.Z }, &headPos, false)) continue;

            const float height = abs(footPos.Y - headPos.Y);
            const float width = height * 0.4f;

            FVector2D top = { headPos.X - width * 0.5, headPos.Y };
            FVector2D bottom = { headPos.X + width * 0.5, footPos.Y };

            if (Config.Visuals.Enabled)
            {
                if (Config.Visuals.Box)
                    Visuals->DrawBox(canvas, top, bottom, 1.f, FLinearColor(1.f, 1.f, 1.f, 1.f));

                if (Config.Visuals.Info)
                    Visuals->DrawNameText(canvas, footPos, playerState);

                if (Config.Visuals.aimFov)
                    Visuals->DrawAimbotFov(canvas);
            }
       }

    } while (false);
}