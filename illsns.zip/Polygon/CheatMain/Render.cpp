#include "Render.h"

#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>

#include "ImGuiElements.h"

#include "../Protect/XorStr.h"
#include "../Protect/LazyImporter.h"

#include "../Detours/WndProc.h"
#include "../CheatMain/Variables.h"

cRender* Render = new cRender;

void cRender::Intialize(IDXGISwapChain* pChain)
{
	SwapChain = pChain;
	Intialized = true;

	if (SUCCEEDED(SwapChain->GetDevice(__uuidof(Device), reinterpret_cast<void**>(&Device))))
	{
		Device->GetImmediateContext(&DeviceContext);

		ID3D11Texture2D* pBackBuffer = nullptr;
		if (SUCCEEDED(SwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer)))
		{
			Device->CreateRenderTargetView(pBackBuffer, NULL, &MainRenderTargetView);
			pBackBuffer->Release();
		}
	}

	ImGui::CreateContext();

	ImGuiIO& io = ImGui::GetIO();
	io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;
	io.IniFilename = NULL;

	HWND hWindow = LI_FN(FindWindowA).safe()(xorstr_("UnrealWindow"), NULL);

	Hooks::oWndProc = (WNDPROC)(SetWindowLongPtr(hWindow, GWLP_WNDPROC, LONG_PTR(Hooks::hkWndProc)));

	ImGui_ImplWin32_Init(hWindow);
	ImGui_ImplDX11_Init(Device, DeviceContext);

	RECT rect;
	if (LI_FN(GetWindowRect).safe()(hWindow, &rect))
	{
		Config.Misc.ScreenSizeX = rect.right - rect.left;
		Config.Misc.ScreenSizeY = rect.bottom - rect.top;
	}

	io.FontDefault = io.Fonts->AddFontFromFileTTF(xorstr_("C:\\Windows\\Fonts\\Verdana.ttf"), 15.f);
	ImGui::EmbraceTheDarkness();
}

void cRender::Begin()
{
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();
}

void cRender::End()
{
	ImGui::Render();
	DeviceContext->OMSetRenderTargets(1, &MainRenderTargetView, NULL);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}