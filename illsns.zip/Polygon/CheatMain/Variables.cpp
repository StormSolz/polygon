#include "Variables.h"

cConfig Config;