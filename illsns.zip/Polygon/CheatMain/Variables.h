#pragma once

class cConfig
{
public:
	struct
	{
		bool Enabled = false;
		bool noCameraShake = false;
		bool noRecoil = false;
		bool noSpread = false;
		bool infAmmo = false;
		bool rapidFire = false;
	} Aimbot;

	struct
	{
		bool Enabled = false;
		bool aimFov = false;

		bool Box = false;
		bool Info = false;
	} Visuals;

	struct
	{
		bool Opened = false;
		int TabPage = 0;
	} Menu;

	struct
	{
		float Fov = 0.f;

		int ScreenSizeX;
		int ScreenSizeY;
	} Misc;
};

extern cConfig Config;