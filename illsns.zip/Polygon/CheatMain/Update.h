#pragma once
#include "../UnrealEngine/SDK.h"

class AGameStateBase;
class UGameViewportClient;
class UCanvas;
class APlayerController;
class APlayerState;
class APawn;

struct cUpdate
{
	struct ue4info
	{
		AGameStateBase* GameState = nullptr;
		APlayerController* PlayerController = nullptr;
		APawn* localCharacter = nullptr;
		TArray<APlayerState*> playerArray;
		bool good = false;
		bool requestWorldToScreen = false;
	};

	ue4info Info;

	void GameThread(UGameViewportClient* viewport, UCanvas* canvas);
};

extern cUpdate update;