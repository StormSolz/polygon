#include "Menu.h"

#include "Variables.h"
#include "ImGuiElements.h"

#include <imgui.h>
#include "../Protect/XorStr.h"

#include "Features/Misc.h"
#include "Features/Aimbot.h"

cMenu* Menu = new cMenu;

void cMenu::Draw()
{
	if (!Config.Menu.Opened)
		return;

	ImGui::SetNextWindowSize(ImVec2(790.f, 600.f));

	ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar;

	ImGui::Begin(xorstr_("Polyhack"), NULL, flags);
	{
		const ImVec2 vecButtonSize = ImVec2(187.f, 30.f);

		if (ImGui::MainTab(xorstr_("Aimbot"), Config.Menu.TabPage == Tabs::AIMBOT, vecButtonSize))
			Config.Menu.TabPage = Tabs::AIMBOT;

		ImGui::SameLine();
		
		if (ImGui::MainTab(xorstr_("Visuals"), Config.Menu.TabPage == Tabs::VISUALS, vecButtonSize))
			Config.Menu.TabPage = Tabs::VISUALS;

		ImGui::SameLine();

		if (ImGui::MainTab(xorstr_("Misc"), Config.Menu.TabPage == Tabs::MISC, vecButtonSize))
			Config.Menu.TabPage = Tabs::MISC;

		ImGui::SameLine();

		if (ImGui::MainTab(xorstr_("Settings"), Config.Menu.TabPage == Tabs::SETTINGS, vecButtonSize))
			Config.Menu.TabPage = Tabs::SETTINGS;

		ImGui::Separator();
		ImGui::Spacing();

		switch (Config.Menu.TabPage)
		{
		case Tabs::AIMBOT:
		{
			if (ImGui::BeginChild(xorstr_("General"), ImVec2(260.f, 400.f), true))
			{
				ImGui::Text(xorstr_("General"));
				ImGui::Separator();
				ImGui::Spacing();

				ImGui::Checkbox(xorstr_("Enabled"), &Config.Aimbot.Enabled);

				ImGui::SliderInt(xorstr_("Aim FOV"), &Aimbot->AimFov, 10, 180);

				ImGui::EndChild();
			}

			ImGui::SameLine();
		
			if (ImGui::BeginChild(xorstr_("Accuracy"), ImVec2(254.f, 400.f), true))
			{
				ImGui::Text(xorstr_("Accuracy"));
				ImGui::Separator();
				ImGui::Spacing();

				ImGui::Checkbox(xorstr_("No Shake"), &Config.Aimbot.noCameraShake);
				ImGui::Checkbox(xorstr_("No Recoil"), &Config.Aimbot.noRecoil);
				ImGui::Checkbox(xorstr_("No Spread"), &Config.Aimbot.noSpread);
				ImGui::Checkbox(xorstr_("Inf Ammo"), &Config.Aimbot.infAmmo);
				ImGui::Checkbox(xorstr_("Rapid Fire"), &Config.Aimbot.rapidFire);

				ImGui::EndChild();
			}

			break;
		}
		case Tabs::VISUALS:
		{
			if (ImGui::BeginChild(xorstr_("Visuals"), ImVec2(254.f, 400.f), true))
			{
				ImGui::Text(xorstr_("Visuals"));
				ImGui::Separator();
				ImGui::Spacing();

				ImGui::Checkbox(xorstr_("Enabled"), &Config.Visuals.Enabled);
				ImGui::Checkbox(xorstr_("Aimbot FOV"), &Config.Visuals.aimFov);


				ImGui::EndChild();
			}

			ImGui::SameLine();

			if (ImGui::BeginChild(xorstr_("Enemies"), ImVec2(254.f, 400.f), true))
			{
				ImGui::Text(xorstr_("Enemies"));
				ImGui::Separator();
				ImGui::Spacing();

				ImGui::Checkbox(xorstr_("Info"), &Config.Visuals.Info);
				ImGui::Checkbox(xorstr_("Box"), &Config.Visuals.Box);

				ImGui::EndChild();
			}

			break;
		}
		case Tabs::MISC:
		{
			if (ImGui::BeginChild(xorstr_("Other"), ImVec2(260.f, 400.f), true))
			{
				ImGui::Text(xorstr_("Other"));
				ImGui::Separator();
				ImGui::Spacing();

				if (ImGui::SliderFloat(xorstr_("FOV"), &Config.Misc.Fov, 60.f, 140.f))
					Misc->shouldChangeFOV = true;

				//ImGui::Checkbox(xorstr_("SpeedHack"), &Misc->shouldEnableSpeed);

				ImGui::EndChild();
			}

			break;
		}
		default:
			break;
		}
	}
	ImGui::End();
}