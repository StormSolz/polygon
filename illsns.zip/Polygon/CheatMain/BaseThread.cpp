#include "BaseThread.h"
#include <Windows.h>

#include "../UnrealEngine/SDK.h"
#include "../Detours/DetourManager.h"

cBaseThread BaseThread;

int cBaseThread::Start()
{
	SDK->Setup();
	DetourManager->Setup();

	return EXIT_SUCCESS;
}