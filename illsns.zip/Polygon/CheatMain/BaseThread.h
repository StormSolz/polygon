#pragma once

class cBaseThread
{
public:
	static int Start();
};

extern cBaseThread BaseThread;