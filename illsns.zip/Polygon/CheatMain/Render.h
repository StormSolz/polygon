#pragma once
#include <d3d11.h>

class cRender
{
public:
	ID3D11Device* Device;
	ID3D11DeviceContext* DeviceContext;
	ID3D11RenderTargetView* MainRenderTargetView;
	IDXGISwapChain* SwapChain;

	bool Intialized = false;
	void Intialize(IDXGISwapChain* pChain);

	void Begin();
	void End();
};

extern cRender* Render;