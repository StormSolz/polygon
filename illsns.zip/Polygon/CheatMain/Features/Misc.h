#pragma once

class APlayerController;

class cMisc
{
public:
	void SetFov(APlayerController* Controller);
	bool shouldChangeFOV = false;

	void SpeedHack(APlayerController* Controller);
	bool shouldEnableSpeed = false;
};

extern cMisc* Misc;