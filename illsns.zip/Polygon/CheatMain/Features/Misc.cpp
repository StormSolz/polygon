#include "Misc.h"

#include "../Variables.h"
#include "../Update.h"

#include "../../UnrealEngine/GameClasses.h"
#include "../../UnrealEngine/GameplayStatics.h"

cMisc* Misc = new cMisc;

void cMisc::SetFov(APlayerController* Controller)
{
	if (shouldChangeFOV)
	{
		shouldChangeFOV = false;
		Controller->FOV(Config.Misc.Fov);
	}
}

void cMisc::SpeedHack(APlayerController* Controller)
{
    if (shouldEnableSpeed)
    {
        /* fixed maybe didnt check
        APawn* Pawn = Controller->K2_GetPawn();
        if (Pawn)
        {
            UCharacterMovementComponent* MovementComp = (UCharacterMovementComponent*)Pawn->GetMovementComponent();
            if (MovementComp)
            {
                MovementComp->MinTimeBetweenTimeStampResets() = -1.f;
            }
        }
        */
    }
}