#pragma once

#include "../../UnrealEngine/Math.h"
#include "../../UnrealEngine/FLinearColor.h"

class UCanvas;
class APlayerState;

class cVisuals
{
public:
	void DrawBox(UCanvas* can, FVector2D& topleft, FVector2D& downright, float Thickness, FLinearColor clr);
	void DrawNameText(UCanvas* can, FVector2D& pos, APlayerState* plyState);
	void DrawAimbotFov(UCanvas* can);
};

extern cVisuals* Visuals;