#pragma once
#include "../../UnrealEngine/Math.h"

class AItem_Weapon_General;
class APlayerController;
class APG_Character;

class cAimbot
{
public:
	int AimFov = 0;

	void Run(APlayerController* plyController, APG_Character* target, bool IsVisible);

	AItem_Weapon_General* weapclass = nullptr;
	void WeaponAccuracy();

	void normalizeAngles(FVector2D angles)
	{
		while (angles.X > 88.f)
			angles.X -= 180.f;

		while (angles.X < -88.f)
			angles.X += 180.f;

		while (angles.Y > 180.f)
			angles.Y -= 360.f;

		while (angles.Y < -180.f)
			angles.Y += 360.f;
	}

	void clampAngles(FVector2D angles)
	{
		if (angles.Y > 89.0)
			angles.Y = 89.0;

		if (angles.Y < -89.0)
			angles.Y = -89.0;

		if (angles.Y > 180.0)
			angles.Y = 180.0;

		if (angles.Y < -180.0)
			angles.Y = -180.0;
	}

	FVector2D GetaimAnglesTo(FVector localPosition, FVector target)
	{
		FVector dPosition = localPosition - target;
		double hypotenuse = sqrt(dPosition.X * dPosition.X + dPosition.Y * dPosition.Y);
		FVector a = { (double)atan2f((float)dPosition.Z, (float)hypotenuse) * 57.295779513082f, (double)atanf((float)dPosition.Y / (float)dPosition.X) * 57.295779513082f, 0 };

		if (dPosition.X >= 0.f)
			a.Y += 180.0f;

		FVector2D aimAngles;
		aimAngles.X = a.X;
		aimAngles.Y = a.Y;
		normalizeAngles(aimAngles);
		clampAngles(aimAngles);
		return aimAngles;
	}

};

extern cAimbot* Aimbot;