#include "Visuals.h"

#include "../Variables.h"
#include "../../UnrealEngine/GameClasses.h"
#include "Aimbot.h"

cVisuals* Visuals = new cVisuals;

void cVisuals::DrawBox(UCanvas* can, FVector2D& topleft, FVector2D& downright, float Thickness, FLinearColor clr)
{
	auto h = downright.Y - topleft.Y;
	auto w = downright.X - topleft.X;

	auto downleft = FVector2D{ topleft.X, downright.Y };
	auto topright = FVector2D{ downright.X, topleft.Y };

	can->K2_DrawLine(topleft, { topleft.X, topleft.Y + h * 1 }, Thickness, clr);
	can->K2_DrawLine(topleft, { topleft.X + w * 1, topleft.Y }, Thickness, clr);

	can->K2_DrawLine(downright, { downright.X, downright.Y - h * 1 }, Thickness, clr);
	can->K2_DrawLine(downright, { downright.X - w * 1, downright.Y }, Thickness, clr);

	can->K2_DrawLine(downleft, { downleft.X, downleft.Y - h * 1 }, Thickness, clr);
	can->K2_DrawLine(downleft, { downleft.X + w * 1, downright.Y }, Thickness, clr);

	can->K2_DrawLine(topright, { topright.X, topright.Y + h * 1 }, Thickness, clr);
	can->K2_DrawLine(topright, { topright.X - w * 1, topright.Y }, Thickness, clr);
}

void cVisuals::DrawNameText(UCanvas* can, FVector2D& pos, APlayerState* plyState)
{
	FString playerName = plyState->GetPlayerName();
	if (playerName.IsValid())
	{	
		can->K2_DrawText(playerName, FVector2D{ pos.X, pos.Y += 10 }, FVector2D{ 1.f, 1.f }, FLinearColor{ 1.f, 1.f, 1.f , 1.f }, 1.0f, FLinearColor{ 0, 0, 0, 0 }, FVector2D{ 0, 0 }, true, true, false, FLinearColor{ 0, 0, 0, 1.f });
	}
}

void cVisuals::DrawAimbotFov(UCanvas* can)
{
	can->DrawCircle({ (float)Config.Misc.ScreenSizeX / 2 , (float)Config.Misc.ScreenSizeY / 2 }, Aimbot->AimFov, 60, FLinearColor{ 1, 1, 1, 1 });
}