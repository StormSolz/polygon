#include "Aimbot.h"

#include "../Update.h"
#include "../Variables.h"

#include "../../UnrealEngine/GameClasses.h"
#include "../../CheatMain/Update.h"

cAimbot* Aimbot = new cAimbot;

void cAimbot::Run(APlayerController* plyController, APG_Character* target, bool IsVisible)
{
	if (!Config.Aimbot.Enabled) 
		return;
		
	if (!IsVisible) return;

	auto const targetheadComponent = target->Hat();
	if (!targetheadComponent) return;

	auto const targetaimPos = targetheadComponent->K2_GetComponentLocation();

	FVector2D targetAimScr;
	if (!plyController->ProjectWorldLocationToScreen(targetaimPos, &targetAimScr, false)) return;

	auto const headComponent = ((APG_Character*)update.Info.localCharacter)->Hat();
	if (!headComponent) return;

	auto const camPos = headComponent->K2_GetComponentLocation();

	float xc = targetAimScr.X - Config.Misc.ScreenSizeX / 2;
	float yc = targetAimScr.Y - Config.Misc.ScreenSizeY / 2;

	float crosshair_dist = sqrtf((xc * xc) + (yc * yc));
	float target_dist = FLT_MAX;

	if (crosshair_dist <= FLT_MAX && crosshair_dist <= target_dist)
	{
		if (crosshair_dist < AimFov)
		{
			FVector2D AngleToTraget1 = GetaimAnglesTo(camPos, targetaimPos);
	
			float& pitch = ((APG_Character*)update.Info.localCharacter)->ControllerPitchRotation();
			float& yaw = ((APG_Character*)update.Info.localCharacter)->ControllerYawRotation();

			yaw = AngleToTraget1.Y;
			pitch = -AngleToTraget1.X;
		}
	}
}

void cAimbot::WeaponAccuracy()
{
	if (update.Info.good && weapclass)
	{
		weapclass->WeaponDamage() = 110;

		if (Config.Aimbot.noRecoil)
			weapclass->WeaponUpRecoil() = 0.f;

		if (Config.Aimbot.noSpread)
			weapclass->CurrentSpread() = 0.f;

		if (Config.Aimbot.rapidFire)
			weapclass->TimeBetweenShots() = 0.03;
		else
			weapclass->TimeBetweenShots() = 0.1;

		if (Config.Aimbot.infAmmo)
			weapclass->CurrentMagazineAmmo() = 10;
	}
}