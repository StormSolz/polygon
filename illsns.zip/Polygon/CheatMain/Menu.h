#pragma once

enum Tabs
{
	AIMBOT,
	VISUALS,
	MISC,
	SETTINGS,
};

class cMenu
{
public:
	void Draw();
};

extern cMenu* Menu;