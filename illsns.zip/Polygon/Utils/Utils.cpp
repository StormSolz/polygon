#include "Utils.h"

#include <Windows.h>
#include <Psapi.h>

std::uintptr_t Utils::FindPattern(const char* moduleName, const char* pattern)
{
	const HMODULE module = GetModuleHandleA(moduleName);

	MODULEINFO moduleInfo;
	GetModuleInformation(GetCurrentProcess(), module, &moduleInfo, sizeof(MODULEINFO));

	std::uintptr_t scanAddrStart = reinterpret_cast<std::uintptr_t>(module);
	std::uintptr_t scanAddrEnd = scanAddrStart + moduleInfo.SizeOfImage;

	for (std::uintptr_t scanAddress = scanAddrStart; scanAddress < scanAddrEnd; scanAddress++)
	{
		bool found = true;

		std::uintptr_t addrOffset = 0;
		for (const char* patternChar = pattern; *patternChar;)
		{
			if (*patternChar == ' ')
			{
				patternChar++;
				continue;
			}
			else if (*patternChar == '?')
			{
				patternChar += 2;
				addrOffset++;
				continue;
			}

			if (*reinterpret_cast<uint8_t*>(scanAddress + addrOffset) != GETBYTE(patternChar))
			{
				found = false;
				break;
			}

			patternChar += 2;
			addrOffset++;
		}

		if (found)
			return scanAddress;
	}

	return NULL;
}

void* Utils::GetAbsAddr(std::uintptr_t inst, std::uintptr_t instOffset, std::uintptr_t instSize)
{
#ifdef _WIN64
	int offset = *reinterpret_cast<int*>(inst + instOffset);
	std::uintptr_t rip = inst + instSize;

	return reinterpret_cast<void*>(rip + static_cast<std::uintptr_t>(offset));
#else
	return reinterpret_cast<void*>(inst);
#endif
}