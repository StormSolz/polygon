#pragma once
#include <cstdint>

#define INRANGE(x, a, b) (x >= a && x <= b) 
#define GETBITS(x) (INRANGE((x & (~0x20)), 'A', 'F') ? ((x & (~0x20)) - 'A' + 0xA) : (INRANGE(x, '0', '9') ? x - '0' : 0))
#define GETBYTE(x) (GETBITS(x[0]) << 4 | GETBITS(x[1]))

namespace Utils
{
	std::uintptr_t FindPattern(const char* moduleName, const char* pattern);
	void* GetAbsAddr(std::uintptr_t inst, std::uintptr_t instOffset = 3, std::uintptr_t instSize = 7);

	namespace Virtual
	{
		static inline void** Get(void* obj)
		{
			return *reinterpret_cast<void***>(obj);
		}

		template <typename T>
		static inline T Get(void* obj, std::uintptr_t index)
		{
			return reinterpret_cast<T>(Get(obj)[index]);
		}

		template <typename T>
		static inline T Get(void** vmt, std::uintptr_t index)
		{
			return reinterpret_cast<T>(vmt[index]);
		}

		template <typename Ret_t, typename ...Args>
		static inline Ret_t Call(void* obj, std::uintptr_t index, Args ...args) noexcept
		{
			using Function_t = Ret_t(__fastcall*)(void*, decltype(args)...);
			return Get<Function_t>(obj, index)(obj, args...);
		}
	}
}