#include "Present.h"

#include "../CheatMain/Render.h"
#include "../CheatMain/Menu.h"
#include "../CheatMain/Update.h"

#include <imgui.h>

HRESULT __fastcall Hooks::hkPresent(IDXGISwapChain* SwapChain, UINT SyncInterval, UINT Flags)
{
	if (!Render->Intialized)
		Render->Intialize(SwapChain);
	
	Render->Begin();
	Menu->Draw();
	Render->End();

	return oPresent(SwapChain, SyncInterval, Flags);
}