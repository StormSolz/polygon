#pragma once
#include <Windows.h>

namespace Hooks
{
	LRESULT __stdcall hkWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	inline WNDPROC oWndProc;
}