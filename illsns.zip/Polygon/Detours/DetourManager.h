#pragma once

#include <Windows.h>
#include <vector>

enum class HookType
{
	Static = 0,
	Runtime,
};

struct Detour
{
	const char* name;
	LPVOID target;
	LPVOID detour;
	LPVOID* original;
	HookType type = HookType::Static;
};

class cDetourManager
{
public:
	void Setup();
private:
	std::vector<Detour> FuncList;
	void AddHook(Detour hk);
};

extern cDetourManager* DetourManager;