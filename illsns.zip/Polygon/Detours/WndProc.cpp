#include "WndProc.h"
#include "../CheatMain/Variables.h"

#include <imgui_impl_win32.h>

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT __stdcall Hooks::hkWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_KEYUP && wParam == VK_INSERT)
	{
		Config.Menu.Opened = !Config.Menu.Opened;
		ImGui::GetIO().MouseDrawCursor = Config.Menu.Opened;
		return 0;
	}

	if (uMsg == WM_KEYDOWN && wParam == VK_INSERT)
		return 0;

	if (Config.Menu.Opened)
	{
		LRESULT result = ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam);
	
		return TRUE;
	}

	return CallWindowProc(Hooks::oWndProc, hWnd, uMsg, wParam, lParam);
}