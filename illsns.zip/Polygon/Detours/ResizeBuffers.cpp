#include "ResizeBuffers.h"

#include "../CheatMain/Render.h"
#include "../CheatMain/Variables.h"


HRESULT __fastcall Hooks::hkResizeBuffers(IDXGISwapChain* SwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags)
{
    if (Render->MainRenderTargetView)
    {
        Render->DeviceContext->OMSetRenderTargets(0, 0, 0);
        Render->MainRenderTargetView->Release();
    }

    HRESULT hResult = oResizeBuffers(SwapChain, BufferCount, Width, Height, NewFormat, SwapChainFlags);

    ID3D11Texture2D* pBackBuffer = nullptr;
    if (SUCCEEDED(SwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer)))
    {
        Render->Device->CreateRenderTargetView(pBackBuffer, NULL, &Render->MainRenderTargetView);
        pBackBuffer->Release();
    }

    Config.Misc.ScreenSizeX = Width;
    Config.Misc.ScreenSizeY = Height;

    D3D11_VIEWPORT vp;
    vp.Width = *reinterpret_cast<float*>(&Width);
    vp.Height = *reinterpret_cast<float*>(&Height);
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    vp.TopLeftX = 0;
    vp.TopLeftY = 0;
    Render->DeviceContext->RSSetViewports(1, &vp);

    return hResult;
}