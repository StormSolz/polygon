#include "GetPlayerViewPoint.h"

#include "../CheatMain/Features/Aimbot.h"
#include "../CheatMain/Features/Misc.h"

#include "../UnrealEngine/GameClasses.h"

void Hooks::hkGetPlayerViewPoint(APlayerController* PlayerController, FVector* Location, FRotator* Rotation)
{
	oGetPlayerViewPoint(PlayerController, Location, Rotation);

	Misc->SetFov(PlayerController);
	Aimbot->WeaponAccuracy();
}