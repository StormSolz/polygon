#include "GetViewPoint.h"
#include "../UnrealEngine/Math.h"

struct FMinimalViewInfo
{
	FVector Location;
	FRotator Rotation;
	float FOV;
};

void __fastcall Hooks::hkGetViewPoint(ULocalPlayer* LocalPlayer, FMinimalViewInfo* OutViewInfo, EStereoscopicPass StereoPass)
{
	oGetViewPoint(LocalPlayer, OutViewInfo, StereoPass);
}