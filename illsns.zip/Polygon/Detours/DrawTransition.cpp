#include "DrawTransition.h"

#include "../UnrealEngine/GameClasses.h"
#include "../CheatMain/Update.h"

void __fastcall Hooks::hkDrawTransition(UGameViewportClient* pGameViewport, UCanvas* pCanvas)
{
	update.GameThread(pGameViewport, pCanvas);

	return oDrawTransition(pGameViewport, pCanvas);
}