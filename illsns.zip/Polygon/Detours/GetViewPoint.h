#pragma once

class ULocalPlayer;
struct FMinimalViewInfo;
enum class EStereoscopicPass;

namespace Hooks
{
	using tGetViewPoint = void(__fastcall*)(ULocalPlayer*, FMinimalViewInfo*, EStereoscopicPass);
	void __fastcall hkGetViewPoint(ULocalPlayer* LocalPlayer, FMinimalViewInfo* OutViewInfo, EStereoscopicPass StereoPass);

	inline tGetViewPoint oGetViewPoint;
}