#pragma once
#include <d3d11.h>

namespace Hooks
{
	using tResizeBuffers = HRESULT(__fastcall*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
	HRESULT __fastcall hkResizeBuffers(IDXGISwapChain* SwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags);

	inline tResizeBuffers oResizeBuffers;
}