#include "ProcessEvent.h"

#include "../UnrealEngine/GameClasses.h"
#include "../CheatMain/Variables.h"

#include "../Protect/XorStr.h"
#include "../UnrealEngine/KismetSystemLibrary.h"

#include "../CheatMain/Update.h"
#include "../CheatMain/Features/Aimbot.h"

void __fastcall Hooks::hkProcessEvent(UObject* Object, UFunction* Function, void* pParams, void* pResult)
{
	static UFunction* ClientStartCameraShake;
	static UFunction* RequestReload_server;

	if (!ClientStartCameraShake || !RequestReload_server)
	{
		ClientStartCameraShake = (UFunction*)UObject::FindObject(xorstr_(L"Engine.PlayerController.ClientStartCameraShake"));
		RequestReload_server = (UFunction*)UObject::FindObject(xorstr_(L"POLYGON.Item_Weapon_General.RequestReload_server"));
	}

	if (ClientStartCameraShake == Function)
	{
		if (Config.Aimbot.noCameraShake)
			return;
	}

	if (RequestReload_server == Function)
		Aimbot->weapclass = (AItem_Weapon_General*)Object;

	return oProcessEvent(Object, Function, pParams, pResult);
}