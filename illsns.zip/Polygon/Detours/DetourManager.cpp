#include "DetourManager.h"

#include "../Utils/Utils.h"
#include "../Protect/XorStr.h"

#include <MinHook.h>

#include "DrawTransition.h"
#include "Present.h"
#include "ResizeBuffers.h"
#include "ProcessEvent.h"
#include "GetPlayerViewPoint.h"
#include "GetViewPoint.h"

cDetourManager* DetourManager = new cDetourManager;

void cDetourManager::Setup()
{
	if (MH_Initialize() == MH_STATUS::MH_OK)
	{
		LPVOID pProcessEvent = reinterpret_cast<LPVOID>(Utils::FindPattern(xorstr_("POLYGON-Win64-Shipping.exe"), xorstr_("40 55 56 57 41 54 41 55 41 56 41 57 48 81 EC F0 ? ? ? 48 8D 6C 24 30")));
		AddHook(Detour{ xorstr_("ProcessEvent"), pProcessEvent, Hooks::hkProcessEvent, reinterpret_cast<LPVOID*>(&Hooks::oProcessEvent) });

		//ConnectingMessage
		LPVOID pDrawTransition = reinterpret_cast<LPVOID>(Utils::FindPattern(xorstr_("POLYGON-Win64-Shipping.exe"), xorstr_("?? ?? ?? ?? ?? ?? ?? ?? 48 81 EC B0 00 00 00 80 B9 88 00 00 00 00 48 8B F2 48 8B F9 0F 85")));
		AddHook(Detour{ xorstr_("DrawTransition"), pDrawTransition, Hooks::hkDrawTransition, reinterpret_cast<LPVOID*>(&Hooks::oDrawTransition) });

		LPVOID pPresentAddr = reinterpret_cast<LPVOID>(Utils::FindPattern(xorstr_("gameoverlayrenderer64.dll"), xorstr_("48 89 6C 24 18 48 89 74 24 20 41 56 48 83 EC 20 41 8B E8")));
		AddHook(Detour{ xorstr_("Present"), pPresentAddr, Hooks::hkPresent, reinterpret_cast<LPVOID*>(&Hooks::oPresent) });

		LPVOID pResizeBuffers = reinterpret_cast<LPVOID>(Utils::FindPattern(xorstr_("GameOverlayRenderer64.dll"), xorstr_("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC 30 44 8B FA")));
		AddHook(Detour{ xorstr_("ResizeBuffers"), pResizeBuffers, Hooks::hkResizeBuffers, reinterpret_cast<LPVOID*>(&Hooks::oResizeBuffers) });

		//L"APlayerController::GetPlayerViewPoint: out_Location, ViewTarget=%s"
		LPVOID pGetPlayerViewPoint = reinterpret_cast<LPVOID>(Utils::FindPattern(xorstr_("POLYGON-Win64-Shipping.exe"), xorstr_("48 89 5C 24 10 ?? ?? ?? ?? 48 8B EC 48 83 EC ?? 48 8B F2 48 8B D9 BA 42 01 00 00 48 8D 4D 38 4D 8B F0 E8")));
		AddHook(Detour{ xorstr_("GetPlayerViewPoint"), pGetPlayerViewPoint, Hooks::hkGetPlayerViewPoint, reinterpret_cast<LPVOID*>(&Hooks::oGetPlayerViewPoint) });
		
		//FLockedViewState::Get
		LPVOID pGetViewPoint = reinterpret_cast<LPVOID>(Utils::FindPattern(xorstr_("POLYGON-Win64-Shipping.exe"), xorstr_("4C 8B DC ?? ?? ?? ?? ?? 57 48 81 EC ?? ?? 00 00 48 8B 05 ?? ?? ?? ?? 48 33 ?? 48 89 84 24 ?? ?? ?? ?? 41 0F 29 73 C8")));
		AddHook(Detour{ xorstr_("GetViewPoint"), pGetViewPoint, Hooks::hkGetViewPoint, reinterpret_cast<LPVOID*>(&Hooks::oGetViewPoint) });

		for (auto& Detour : FuncList)
		{
			if (!Detour.target)
				continue;

			if (MH_CreateHook(Detour.target, Detour.detour, Detour.original) == MH_STATUS::MH_OK);
			{
				if (MH_EnableHook(Detour.target) != MH_STATUS::MH_OK)
					break;
			}
		}
	}
}

void cDetourManager::AddHook(Detour hk)
{
	FuncList.push_back(hk);
}