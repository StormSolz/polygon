#pragma once

class UObject;
class UFunction;

namespace Hooks
{
	using tProcessEvent = void(__fastcall*)(UObject*, UFunction*, void*, void*);
	void __fastcall hkProcessEvent(UObject* Object, UFunction* Function, void* pParams, void* pResult);

	inline tProcessEvent oProcessEvent;
}