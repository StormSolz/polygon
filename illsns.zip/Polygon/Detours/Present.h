#pragma once
#include <d3d11.h>

namespace Hooks
{
	using tPresent = HRESULT(__fastcall*)(IDXGISwapChain*, UINT, UINT);
	HRESULT __fastcall hkPresent(IDXGISwapChain* SwapChain, UINT SyncInterval, UINT Flags);

	inline tPresent oPresent;
}