#pragma once

class UGameViewportClient;
class UCanvas;

namespace Hooks
{
	using tDrawTransition = void(__fastcall*)(UGameViewportClient*, UCanvas*);
	void __fastcall hkDrawTransition(UGameViewportClient* pGameViewport, UCanvas* pCanvas);

	inline tDrawTransition oDrawTransition;
}