#pragma once

class APlayerController;
struct FVector;
struct FRotator;

namespace Hooks
{
	using tGetPlayerViewPoint = void(__fastcall*)(APlayerController*, FVector*, FRotator*);
	void hkGetPlayerViewPoint(APlayerController* PlayerController, FVector* Location, FRotator* Rotation);

	inline tGetPlayerViewPoint oGetPlayerViewPoint;
}