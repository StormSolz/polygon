#include <Windows.h>

#include "CheatMain/BaseThread.h"
#include "Protect/LazyImporter.h"

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH:
    {
        LI_FN(DisableThreadLibraryCalls)(hinstDLL);

        HANDLE pHandleNewTimer = NULL;
        HANDLE pCurrentProcess = NULL;
        DWORD lpflOldProtect = NULL;

        pCurrentProcess = LI_FN(GetCurrentProcess)();
        if (LI_FN(VirtualProtectEx)(pCurrentProcess, hinstDLL, 0x40, PAGE_READWRITE, &lpflOldProtect))
        {
            for (size_t i = 0; i < 4; i++) {
                *((DWORD*)hinstDLL + i) = 0;
            }

            /*
            *(DWORD*)hinstDLL = 0;
            *((DWORD*)hinstDLL + 1) = 0;
            *((DWORD*)hinstDLL + 2) = 0;
            *((DWORD*)hinstDLL + 3) = 0;
            *((DWORD*)hinstDLL + 4) = 0;
            */
        }

        if ((LI_FN(VirtualProtectEx)(pCurrentProcess, hinstDLL, 0x108, PAGE_READWRITE, &lpflOldProtect)))
            memset(hinstDLL, 0, 0x108);

        LI_FN(CreateTimerQueueTimer).safe()((PHANDLE)&pHandleNewTimer, 0, (WAITORTIMERCALLBACK)BaseThread.Start, 0, 900, 0, 0);

        break;
    }
    case DLL_PROCESS_DETACH:

        break;
    }

    return TRUE;
}