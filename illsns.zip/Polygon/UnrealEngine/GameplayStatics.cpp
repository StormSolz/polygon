#include "GameplayStatics.h"
#include "../Protect/XorStr.h"

#include "SDK.h"

UGameplayStatics* GameplayStatics = new UGameplayStatics;

UObject* UGameplayStatics::GetClass()
{
	static UObject* gameplayStaticsClass;
	if (!gameplayStaticsClass)
		gameplayStaticsClass  = UObject::FindObject(xorstr_(L"Engine.Default__GameplayStatics"));

	return gameplayStaticsClass;
}

struct UGameplayStatics_GetPlayerController_Params
{
	UObject* WorldContextObject;
	int32_t PlayerIndex;
	APlayerController* ReturnValue;
};

APlayerController* UGameplayStatics::GetPlayerController(UObject* WorldContextObject, int32_t PlayerIndex)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)(UObject::FindObject(xorstr_(L"Engine.GameplayStatics.GetPlayerController")));

	UGameplayStatics_GetPlayerController_Params params{};
	params.WorldContextObject = WorldContextObject;
	params.PlayerIndex = PlayerIndex;

	UObject::ProcessEvent(GetClass(), function, &params);

	return params.ReturnValue;
}

struct UGameplayStatics_GetPlayerPawn_Params
{
	UObject* WorldContextObject;
	int32_t PlayerIndex;
	APawn* ReturnValue;
};

APawn* UGameplayStatics::STATIC_GetPlayerPawn(UObject* WorldContextObject, int32_t PlayerIndex)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.GameplayStatics.GetPlayerPawn"));

	UGameplayStatics_GetPlayerPawn_Params params{};
	params.WorldContextObject = WorldContextObject;
	params.PlayerIndex = PlayerIndex;

	return params.ReturnValue;
}

struct UGameplayStatics_GetAllActorsOfClass_Params
{
	UObject* WorldContextObject;
	UClass* ActorClass;
	TArray<AActor*> OutActors;
};

void UGameplayStatics::STATIC_GetAllActorsOfClass(UObject* WorldContextObject, UClass* ActorClass, TArray<AActor*>* OutActors)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.GameplayStatics.GetAllActorsOfClass"));

	UGameplayStatics_GetAllActorsOfClass_Params params{};
	params.WorldContextObject = WorldContextObject;
	params.ActorClass = ActorClass;

	UObject::ProcessEvent(GetClass(), function, &params);

	if (OutActors != nullptr)
		*OutActors = params.OutActors;
}

struct UGameplayStatics_GetActorOfClass_Params
{
	UObject* WorldContextObject;
	UClass* ActorClass;
	AActor* ReturnValue;
};

AActor* UGameplayStatics::STATIC_GetActorOfClass(UObject* WorldContextObject, UClass* ActorClass)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.GameplayStatics.GetActorOfClass"));

	UGameplayStatics_GetActorOfClass_Params params;
	params.WorldContextObject = WorldContextObject;
	params.ActorClass = ActorClass;

	UObject::ProcessEvent(GetClass(), function, &params);

	return params.ReturnValue;
}

struct UGameplayStatics_GetGameState_Params
{
	UObject* WorldContextObject;
	AGameStateBase* ReturnValue;
};

AGameStateBase* UGameplayStatics::STATIC_GetGameState(UObject* WorldContextObject)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.GameplayStatics.GetGameState"));

	UGameplayStatics_GetGameState_Params params{};
	params.WorldContextObject = WorldContextObject;

	UObject::ProcessEvent(GetClass(), function, &params);

	return params.ReturnValue;
}

struct UGameplayStatics_GetObjectClass_Params
{
	UObject* Object;
	UClass* ReturnValue;
};

UClass* UGameplayStatics::STATIC_GetObjectClass(UObject* Object)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.GameplayStatics.GetObjectClass"));

	UGameplayStatics_GetObjectClass_Params params{};
	params.Object = Object;

	UObject::ProcessEvent(GetClass(), function, &params);

	return params.ReturnValue;
}