#pragma once
#include <cstdint>

class APlayerController;
class AGameStateBase;
class UFunction;
class UObject;
class AActor;
class APawn;
class UClass;

template<typename T>
class TArray;

class UGameplayStatics
{
public:
	static UObject* GetClass();
	APlayerController* GetPlayerController(UObject* WorldContextObject, int32_t PlayerIndex);
	APawn* STATIC_GetPlayerPawn(UObject* WorldContextObject, int32_t PlayerIndex);
	void STATIC_GetAllActorsOfClass(UObject* WorldContextObject, UClass* ActorClass, TArray<AActor*>* OutActors);
	AActor* STATIC_GetActorOfClass(UObject* WorldContextObject, UClass* ActorClass);
	AGameStateBase* STATIC_GetGameState(UObject* WorldContextObject);
	UClass* STATIC_GetObjectClass(UObject* Object);
};

extern UGameplayStatics* GameplayStatics;