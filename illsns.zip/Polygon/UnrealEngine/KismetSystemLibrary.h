#pragma once

class FString;
class UObject;

class AActor;
struct FVector;

class cKismetSystemLibrary
{
public:
	static UObject* GetClass();
	UObject* STATIC_GetOuterObject(UObject* Object);
	FString STATIC_GetObjectName(UObject* Object);
	void STATIC_GetActorBounds(AActor* Actor, FVector* Origin, FVector* BoxExtent);
};

extern cKismetSystemLibrary* KismetSystemLibrary;