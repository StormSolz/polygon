#include "GameClasses.h"
#include "../Protect/XorStr.h"

struct APlayerController_ProjectWorldLocationToScreen_Params
{
	FVector WorldLocation;
	FVector2D ScreenLocation;
	bool bPlayerViewportRelative;
	bool ReturnValue;
};

bool APlayerController::ProjectWorldLocationToScreen(const FVector& WorldLocation, FVector2D* ScreenLocation, bool bPlayerViewportRelative)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.PlayerController.ProjectWorldLocationToScreen"));

	APlayerController_ProjectWorldLocationToScreen_Params params;
	params.WorldLocation = WorldLocation;
	params.bPlayerViewportRelative = bPlayerViewportRelative;

	UObject::ProcessEvent(this, function, &params);

	if (ScreenLocation != nullptr)
		*ScreenLocation = params.ScreenLocation;

	return params.ReturnValue;
}

void APlayerController::FOV(float NewFOV)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.PlayerController.FOV"));

	UObject::ProcessEvent(this, function, &NewFOV);
}

struct AController_K2_GetPawn_Params
{
	APawn* ReturnValue;
};

APawn* APlayerController::K2_GetPawn()
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Controller.K2_GetPawn"));

	AController_K2_GetPawn_Params params{};
	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct APawn_GetMovementComponent_Params
{
	UPawnMovementComponent* ReturnValue;
};

UPawnMovementComponent* APawn::GetMovementComponent()
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Pawn.GetMovementComponent"));

	APawn_GetMovementComponent_Params params{};
	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct APlayerState_GetPlayerName_Params
{
	FString ReturnValue;
};

FString APlayerState::GetPlayerName()
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.PlayerState.GetPlayerName"));

	APlayerState_GetPlayerName_Params params;
	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct AActor_K2_GetActorLocation_Params
{
	FVector ReturnValue;
};

FVector AActor::K2_GetActorLocation()
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Actor.K2_GetActorLocation"));

	AActor_K2_GetActorLocation_Params params;
	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct AActor_GetOwner_Params
{
	class AActor* ReturnValue;
};

AActor* AActor::GetOwner()
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Actor.GetOwner"));

	AActor_GetOwner_Params params;
	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct AActor_GetInstigator_Params
{
	APawn* ReturnValue;
};

APawn* AActor::GetInstigator()
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Actor.GetInstigator"));

	AActor_GetInstigator_Params params;
	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct AActor_GetComponentByClass_Params
{
	UClass* ComponentClass;
	UActorComponent* ReturnValue;
};

UActorComponent* AActor::GetComponentByClass(UClass* ComponentClass)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Actor.GetComponentByClass"));

	AActor_GetComponentByClass_Params params;
	params.ComponentClass = ComponentClass;

	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct AActor_GetActorBounds_Params
{
	bool bOnlyCollidingComponents;
	FVector Origin;
	FVector BoxExtent;
	bool bIncludeFromChildActors;
};

void AActor::GetActorBounds(bool bOnlyCollidingComponents, FVector* Origin, FVector* BoxExtent, bool bIncludeFromChildActors)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Actor.GetActorBounds"));

	AActor_GetActorBounds_Params params;
	params.bOnlyCollidingComponents = bOnlyCollidingComponents;
	params.bIncludeFromChildActors = bIncludeFromChildActors;

	UObject::ProcessEvent(this, function, &params);

	if (Origin != nullptr)
		*Origin = params.Origin;
	if (BoxExtent != nullptr)
		*BoxExtent = params.BoxExtent;
}

struct UCanvas_K2_DrawText_Params
{
	UFont* RenderFont;
	FString RenderText;
	FVector2D ScreenPosition;
	FVector2D Scale;
	FLinearColor RenderColor;
	float Kerning;
	FLinearColor ShadowColor;
	FVector2D ShadowOffset;
	bool bCentreX;
	bool bCentreY;
	bool bOutlined;
	FLinearColor OutlineColor;
};

void UCanvas::K2_DrawText(const FString& RenderText, const FVector2D& ScreenPosition, const FVector2D& Scale,
	const FLinearColor& RenderColor, float Kerning, const FLinearColor& ShadowColor, const FVector2D& ShadowOffset,
	bool bCentreX, bool bCentreY, bool bOutlined, const FLinearColor& OutlineColor)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Canvas.K2_DrawText"));

	UCanvas_K2_DrawText_Params params;
	params.RenderFont = SDK->RobotoFont;
	params.RenderText = RenderText;
	params.ScreenPosition = ScreenPosition;
	params.Scale = Scale;
	params.RenderColor = RenderColor;
	params.Kerning = Kerning;
	params.ShadowColor = ShadowColor;
	params.ShadowOffset = ShadowOffset;
	params.bCentreX = bCentreX;
	params.bCentreY = bCentreY;
	params.bOutlined = bOutlined;
	params.OutlineColor = OutlineColor;

	UObject::ProcessEvent(this, function, &params);
}

void UCanvas::DrawCircle(FVector2D pos, int radius, int numSides, FLinearColor Color)
{
	const float PI = 3.1415927f;

	float Step = PI * 2.0 / numSides;
	int Count = 0;
	FVector2D V[128];
	for (float a = 0; a < PI * 2.0; a += Step) 
	{
		float X1 = radius * cos(a) + pos.X;
		float Y1 = radius * sin(a) + pos.Y;
		float X2 = radius * cos(a + Step) + pos.X;
		float Y2 = radius * sin(a + Step) + pos.Y;
		V[Count].X = X1;
		V[Count].Y = Y1;
		V[Count + 1].X = X2;
		V[Count + 1].Y = Y2;
		this->K2_DrawLine({ V[Count].X, V[Count].Y }, { X2, Y2 }, 1.0f, Color);
	}
}

struct UCanvas_K2_DrawLine_Params
{
	FVector2D ScreenPositionA;
	FVector2D ScreenPositionB;
	float Thickness;
	FLinearColor RenderColor;
};

void UCanvas::K2_DrawLine(const FVector2D& ScreenPositionA, const FVector2D& ScreenPositionB, float Thickness, const FLinearColor& RenderColor)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Canvas.K2_DrawLine"));

	UCanvas_K2_DrawLine_Params params;
	params.ScreenPositionA = ScreenPositionA;
	params.ScreenPositionB = ScreenPositionB;
	params.Thickness = Thickness;
	params.RenderColor = RenderColor;

	UObject::ProcessEvent(this, function, &params);
}

struct UCanvas_K2_DrawBox_Params
{
	FVector2D ScreenPosition;
	FVector2D ScreenSize;
	float Thickness;
	FLinearColor RenderColor;
};

void UCanvas::K2_DrawBox(const FVector2D& ScreenPosition, const FVector2D& ScreenSize, float Thickness, const FLinearColor& RenderColor)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Canvas.K2_DrawBox"));

	UCanvas_K2_DrawBox_Params params;
	params.ScreenPosition = ScreenPosition;
	params.ScreenSize = ScreenSize;
	params.Thickness = Thickness;
	params.RenderColor = RenderColor;

	UObject::ProcessEvent(this, function, &params);
}

struct UCanvas_K2_Project_Params
{
	FVector WorldLocation;
	FVector ReturnValue;
};

FVector UCanvas::K2_Project(const FVector& WorldLocation)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Canvas.K2_Project"));

	UCanvas_K2_Project_Params params;
	params.WorldLocation = WorldLocation;

	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct AController_LineOfSightTo_Params
{
	AActor* Other;
	FVector ViewPoint;
	bool bAlternateChecks;
	bool ReturnValue;
};

bool AController::LineOfSightTo(AActor* Other, const FVector& ViewPoint, bool bAlternateChecks)
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.Controller.LineOfSightTo"));

	AController_LineOfSightTo_Params params;
	params.Other = Other;
	params.ViewPoint = ViewPoint;
	params.bAlternateChecks = bAlternateChecks;

	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct UHealthStatsComponent_GetHealth_Params
{
	int ReturnValue;
};

int UHealthStatsComponent::GetHealth()
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"POLYGON.HealthStatsComponent.GetHealth"));

	UHealthStatsComponent_GetHealth_Params params;

	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}

struct USceneComponent_K2_GetComponentLocation_Params
{
	FVector ReturnValue;
};

FVector USceneComponent::K2_GetComponentLocation()
{
	static UFunction* function;
	if (function == nullptr)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.SceneComponent.K2_GetComponentLocation"));

	USceneComponent_K2_GetComponentLocation_Params params;
	UObject::ProcessEvent(this, function, &params);

	return params.ReturnValue;
}