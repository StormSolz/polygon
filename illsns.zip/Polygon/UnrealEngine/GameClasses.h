#pragma once
#include "SDK.h"
#include "../Protect/XorStr.h"

class UWorld : public UObject
{
public:
	class AGameStateBase* GameState()
	{
		static int Offset;
		if (Offset == NULL)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"GameState"));
			if (propertys)
			{
				Offset = propertys->OffsetInternal();
			}
		}

		return *reinterpret_cast<AGameStateBase**>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.World"));

		return ptr;
	}
};

class UCanvas : public UObject
{
public:
	void K2_DrawText(const FString& RenderText, const FVector2D& ScreenPosition, const FVector2D& Scale, 
		const FLinearColor& RenderColor, float Kerning, const FLinearColor& ShadowColor, const FVector2D& ShadowOffset,
		bool bCentreX, bool bCentreY, bool bOutlined, const FLinearColor& OutlineColor);

	void DrawCircle(FVector2D pos, int radius, int numSides, FLinearColor Color);

	void K2_DrawLine(const FVector2D& ScreenPositionA, const FVector2D& ScreenPositionB, float Thickness, const FLinearColor& RenderColor);
	void K2_DrawBox(const FVector2D& ScreenPosition, const FVector2D& ScreenSize, float Thickness, const FLinearColor& RenderColor);
	FVector K2_Project(const FVector& WorldLocation);
};

class ULocalPlayer : public UObject
{
public:
	class APlayerController* PlayerController()
	{
		static int Offset;
		if (Offset == NULL)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"PlayerController"));
			if (propertys)
			{
				Offset = propertys->OffsetInternal();
			}
		}

		return *reinterpret_cast<APlayerController**>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.Player"));

		return ptr;
	}
};

class UGameInstance : public UObject
{
public:
	TArray<class ULocalPlayer*> LocalPlayers()
	{
		static int Offset;
		if (Offset == NULL)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"LocalPlayers"));
			if (propertys)
			{
				Offset = propertys->OffsetInternal();
			}
		}

		return *reinterpret_cast<TArray<ULocalPlayer*>*>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.GameInstance"));

		return ptr;
	}
};

class UGameViewportClient : public UObject
{
public:
	class UGameInstance* GameInstance()
	{
		static int Offset;
		if (Offset == NULL)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"GameInstance"));
			if (propertys)
			{
				Offset = propertys->OffsetInternal();
			}
		}

		return *reinterpret_cast<UGameInstance**>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.GameViewportClient"));

		return ptr;
	}
};

class UActorComponent : public UObject
{
public:

};

class USceneComponent : public UActorComponent
{
public:
	FVector K2_GetComponentLocation();
};

class UPrimitiveComponent : public USceneComponent {};

class UMeshComponent : public UPrimitiveComponent {};

class UStaticMeshComponent : public UMeshComponent {};

class USkeletalMeshComponent : public UActorComponent {};

class APawn;
class AActor : public UObject
{
public:
	FVector K2_GetActorLocation();
	AActor* GetOwner();
	APawn* GetInstigator();
	class UActorComponent* GetComponentByClass(UClass* ComponentClass);
	void GetActorBounds(bool bOnlyCollidingComponents, FVector* Origin, FVector* BoxExtent, bool bIncludeFromChildActors);
};

class APlayerState;
class AController : public AActor
{
public:
	bool LineOfSightTo(AActor* Other, const FVector& ViewPoint, bool bAlternateChecks);

	class APlayerState* PlayerState()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"PlayerState"));
			if (propertys)
			{
				Offset = propertys->OffsetInternal();
			}
		}

		return *reinterpret_cast<APlayerState**>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.Controller"));

		return ptr;
	}
};

class APlayerController : public AController
{
public:
	bool ProjectWorldLocationToScreen(const FVector& WorldLocation, FVector2D* ScreenLocation, bool bPlayerViewportRelative);

	void FOV(float NewFOV);
	class APawn* K2_GetPawn();
};

class APlayerState;
class AGameStateBase : public UObject
{
public:
	TArray<APlayerState*> PlayerArray()
	{
		static int Offset;
		if (Offset == NULL)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"PlayerArray"));
			if (propertys)
			{
				Offset = propertys->OffsetInternal();
			}
		};

		return *reinterpret_cast<TArray<APlayerState*>*>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.GameStateBase"));

		return ptr;
	}
};

class APlayerState : public AActor
{
public:
	FString GetPlayerName();

	class APawn* PawnPrivate()
	{
		static int Offset;
		if (Offset == NULL)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"PawnPrivate"));
			if (propertys)
			{
				Offset = propertys->OffsetInternal();
			}
		}

		return *reinterpret_cast<APawn**>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.PlayerState"));
			
		return ptr;
	}
};

class APG_PlayerState_Game : public APlayerState
{
public:
	char Team()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"Team"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<char*>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"POLYGON.PG_PlayerState_Game"));

		return ptr;
	}
};

class UPawnMovementComponent : public UObject
{
public:
};

class UCharacterMovementComponent : public UPawnMovementComponent
{
public:
	float& MinTimeBetweenTimeStampResets()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"MinTimeBetweenTimeStampResets"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<float*>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.CharacterMovementComponent"));

		return ptr;
	}
};

class APawn : public AActor
{
public:
	UPawnMovementComponent* GetMovementComponent();

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"Engine.Pawn"));

		return ptr;
	}
};

class AItem_General : public AActor
{
public:

};

enum class POLYGON_EWeaponType : uint8_t
{
	EWeaponType__NONE = 0,
	EWeaponType__RIFLE = 1,
	EWeaponType__SNIPER = 2,
	EWeaponType__PISTOL = 3,
	EWeaponType__EWeaponType_MAX = 4,

};

class AItem_Weapon_General : public AItem_General
{
public:
	int& WeaponDamage()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"WeaponDamage"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<int*>(uintptr_t(this) + Offset);
	}

	POLYGON_EWeaponType& WeaponType()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"WeaponType"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<POLYGON_EWeaponType*>(uintptr_t(this) + Offset);
	}

	float& TimeBetweenShots()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"TimeBetweenShots"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<float*>(uintptr_t(this) + Offset);
	}

	float& WeaponUpRecoil()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"WeaponUpRecoil"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<float*>(uintptr_t(this) + Offset);
	}

	float& CurrentSpread()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"CurrentSpread"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<float*>(uintptr_t(this) + Offset);
	}

	float& SpreadShot()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"SpreadShot"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<float*>(uintptr_t(this) + Offset);
	}

	int& CurrentMagazineAmmo()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"CurrentMagazineAmmo"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<int*>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"POLYGON.Item_Weapon_General"));

		return ptr;
	}
};

class UWeaponComponent : public UActorComponent
{
public:
	class AItem_Weapon_General* CurrentWeapon()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = UWeaponComponent::StaticClass()->FindPropertyByName(xorstr_(L"PrimaryWeapon"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<AItem_Weapon_General**>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"POLYGON.WeaponComponent"));

		return ptr;
	}
};

class UHealthStatsComponent : UActorComponent
{
public:
	int GetHealth();
};

class APG_Character : public APawn
{
public:
	class UStaticMeshComponent* Hat()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"Hat"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<UStaticMeshComponent**>(uintptr_t(this) + Offset);
	}

	class UHealthStatsComponent* HealthStatsComponent()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"HealthStatsComponent"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<UHealthStatsComponent**>(uintptr_t(this) + Offset);
	}

	void StartShooting();

	float& ControllerPitchRotation()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"ControllerPitchRotation"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<float*>(uintptr_t(this) + Offset);
	}

	float& ControllerYawRotation()
	{
		static int Offset;
		if (!Offset)
		{
			FProperty* propertys = StaticClass()->FindPropertyByName(xorstr_(L"ControllerYawRotation"));
			if (propertys)
				Offset = propertys->OffsetInternal();
		}

		return *reinterpret_cast<float*>(uintptr_t(this) + Offset);
	}

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if (!ptr)
			ptr = (UClass*)UObject::FindObject(xorstr_(L"POLYGON.PG_Character"));

		return ptr;
	}
};