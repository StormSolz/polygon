#pragma once
#include <cwchar>
#include <string>
#include <locale>
#include <set>

#include "Math.h"
#include "FLinearColor.h"

class UWorld;
class UFont;

class cSDK
{
public:
	UWorld** GWorld;
	UFont* RobotoFont;

	bool Setup();
};

extern cSDK* SDK;

class UFunction;
class UClass;

class UObject
{
public:
	static UClass* GetPrivateStaticClass();
	static UObject* FindObject(const wchar_t* name);

	static void ProcessEvent(UObject* Object, UFunction* Function, void* Params);
};

class UFont : public UObject
{
public:

};

enum EFindName
{
	FNAME_Find,
	FNAME_Add,
	FNAME_Replace_Not_Safe_For_Threading,
};

struct FName
{

};

struct FProperty
{
	int OffsetInternal() const
	{
		return *reinterpret_cast<int*>(std::uintptr_t(this) + 0x4C);
	}
};

class UClass : public UObject
{
public:
	FProperty* FindPropertyByName(const wchar_t* name);
};

class UFunction : public UObject
{
public:
};

template<typename T>
class TArray
{
public:
	friend class FString;

	TArray()
	{
		Data = nullptr;
		Count = Size = 0;
	}

	int Num() const
	{
		return Count;
	}

	T& operator[](int i)
	{
		return Data[i];
	}

	const T& operator[](int i) const
	{
		return Data[i];
	}

	bool IsValidIndex(int i) const
	{
		return i < Num();
	}

//private:
	T* Data;
	int Count;
	int Size;
};

class FString : TArray<wchar_t>
{
public:
	FString() {};

	FString(const wchar_t* other)
	{
		Size = Count = *other ? static_cast<int>(std::wcslen(other)) + 1 : 0;

		if (Count)
		{
			Data = const_cast<wchar_t*>(other);
		}
	}

	bool IsValid() const
	{
		return Data != nullptr;
	}

	wchar_t* c_wstr() const
	{
		return Data;
	}

	std::string ToString() const
	{
		size_t length = std::wcslen(Data);
		std::string str(length, '\0');
		std::use_facet<std::ctype<wchar_t>>(std::locale()).narrow(Data, Data + length, '?', &str[0]);
		return str;
	}
};