#include "SDK.h"

#include "../Utils/Utils.h"
#include "../Protect/XorStr.h"
#include "../Detours/ProcessEvent.h"
#include "../CheatMain/Variables.h"

cSDK* SDK = new cSDK;

static UClass* (*GetPrivateStaticClassFn)();
static UObject* (*StaticFindObject)(UClass*, void*, const wchar_t*, unsigned __int8);

static FProperty* (*FindPropertyByNameFn)(UClass*, FName*);
static FName* (*FNameFn)(void*, const wchar_t*, int);

bool cSDK::Setup()
{
	//RelativeScale3D
	std::uintptr_t propertyfindFuncPtr = Utils::FindPattern(xorstr_("POLYGON-Win64-Shipping.exe"), xorstr_("FF 15 ?? ?? ?? ?? ?? 89 AE 90 01 00 00 ?? ??"));

	FNameFn = decltype(FNameFn)(reinterpret_cast<uintptr_t>(Utils::GetAbsAddr(propertyfindFuncPtr + 0x74, 1, 5)));

	if (!FNameFn)
		return false;

	FindPropertyByNameFn = decltype(FindPropertyByNameFn)(reinterpret_cast<uintptr_t>(Utils::GetAbsAddr(propertyfindFuncPtr + 0x81, 1, 5)));

	if (!FindPropertyByNameFn)
		return false;

	//Property '%s' not found on object '%s'
	std::uintptr_t objectFuncPtr = Utils::FindPattern(xorstr_("POLYGON-Win64-Shipping.exe"), xorstr_("E8 ?? ?? ?? ?? 84 C0 0F 84 ?? 01 00 00 48 8B 44 24 30 48 8D 95 ?? ?? 00 00 41 B1 01"));

	GetPrivateStaticClassFn = decltype(GetPrivateStaticClassFn)(reinterpret_cast<uintptr_t>(Utils::GetAbsAddr(objectFuncPtr + 0x55, 1, 5)));

	if (!GetPrivateStaticClassFn)
		return false;

	StaticFindObject = decltype(StaticFindObject)(reinterpret_cast<uintptr_t>(Utils::GetAbsAddr(objectFuncPtr + 0x6B, 1, 5)));

	if (!StaticFindObject)
		return false;

	//FSeamlessTravelHandler::Tick -- "SeamlessTravel FlushLevelStreaming"
	std::uintptr_t worldPtr = Utils::FindPattern(xorstr_("POLYGON-Win64-Shipping.exe"), xorstr_("48 89 05 ?? ?? ?? ?? ?? 8B ?? ?? F6 86 ?? 01 00 00 40 75 ?? 8B"));
	worldPtr = reinterpret_cast<uintptr_t>(Utils::GetAbsAddr(worldPtr));

	GWorld = reinterpret_cast<UWorld**>(worldPtr);

	RobotoFont = (UFont*)UObject::FindObject(xorstr_(L"/Engine/EngineFonts/Roboto.Roboto"));
	if (!RobotoFont)
		return false;

	return true;
}

UClass* UObject::GetPrivateStaticClass()
{
	return GetPrivateStaticClassFn();
}

UObject* UObject::FindObject(const wchar_t* name)
{
	UClass* ObjectClass = UObject::GetPrivateStaticClass();
	if (!ObjectClass)
		return nullptr;

	return StaticFindObject(ObjectClass, nullptr, name, NULL);
}

void UObject::ProcessEvent(UObject* Object, UFunction* Function, void* Params)
{
	Hooks::oProcessEvent(Object, Function, Params, nullptr);
}

FProperty* UClass::FindPropertyByName(const wchar_t* name)
{
	FName* propertyName = {};
	FNameFn(&propertyName, name, FNAME_Find);

	if (propertyName != nullptr)
	{
		FProperty* curProperty = FindPropertyByNameFn(this, propertyName);
		return curProperty;
	}

	return nullptr;
}