#include "KismetSystemLibrary.h"
#include "SDK.h"

#include "../Protect/XorStr.h"

cKismetSystemLibrary* KismetSystemLibrary = new cKismetSystemLibrary;

UObject* cKismetSystemLibrary::GetClass()
{
	static UObject* kismetSystemLibrary;
	if (!kismetSystemLibrary)
		kismetSystemLibrary = UObject::FindObject(xorstr_(L"Engine.Default__KismetSystemLibrary"));

	return kismetSystemLibrary;
}

struct UKismetSystemLibrary_GetOuterObject_Params
{
	UObject* Object;
	UObject* ReturnValue;
};

UObject* cKismetSystemLibrary::STATIC_GetOuterObject(UObject* Object)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.KismetSystemLibrary.GetOuterObject"));

	UKismetSystemLibrary_GetOuterObject_Params params;
	params.Object = Object;

	UObject::ProcessEvent(GetClass(), function, &params);

	return params.ReturnValue;
}

struct UKismetSystemLibrary_GetActorBounds_Params
{
	AActor* Actor;
	FVector Origin;
	FVector BoxExtent;
};

void cKismetSystemLibrary::STATIC_GetActorBounds(AActor* Actor, FVector* Origin, FVector* BoxExtent)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.KismetSystemLibrary.GetActorBounds"));

	UKismetSystemLibrary_GetActorBounds_Params params;
	params.Actor = Actor;

	UObject::ProcessEvent(GetClass(), function, &params);

	if (Origin != nullptr)
		*Origin = params.Origin;
	if (BoxExtent != nullptr)
		*BoxExtent = params.BoxExtent;
}

struct UKismetSystemLibrary_GetObjectName_Params
{
	UObject* Object; 
	FString ReturnValue; 
};

FString cKismetSystemLibrary::STATIC_GetObjectName(UObject* Object)
{
	static UFunction* function;
	if (!function)
		function = (UFunction*)UObject::FindObject(xorstr_(L"Engine.KismetSystemLibrary.GetObjectName"));

	UKismetSystemLibrary_GetObjectName_Params params{};
	params.Object = Object;

	UObject::ProcessEvent(GetClass(), function, &params);

	return params.ReturnValue;
}